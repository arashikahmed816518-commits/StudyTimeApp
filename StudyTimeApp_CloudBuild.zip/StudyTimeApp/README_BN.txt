Study Time — Android অ্যাপ প্রজেক্ট

এই প্রজেক্টে যা আছে:
- বাংলা Study Time স্ক্রিন
- ডিফল্ট রিমাইন্ডার রাত ৮টা
- সময় বেছে নিয়ে প্রতিদিনের রিমাইন্ডার সেট করা
- বাংলা নোটিফিকেশন
- ফোন রিস্টার্ট হলে রিমাইন্ডার আবার সেট করার ব্যবস্থা
- GitHub Actions দিয়ে ক্লাউডে APK build করার workflow

শুধু Android ফোন দিয়ে APK বানানোর পদ্ধতি (GitHub Actions):
1. এই ZIP ফাইলটি ফোনে Download করে Extract করুন।
2. GitHub-এ লগইন করে একটি নতুন Public বা Private repository তৈরি করুন, যেমন StudyTimeApp।
3. Extract করা ফোল্ডারের ভেতরের ফাইলগুলো repository-র root-এ upload/commit করুন। পুরো ZIP-টিকে শুধু একটি ফাইল হিসেবে upload করলে হবে না—ফাইলগুলো extract করা অবস্থায় থাকতে হবে। .github/workflows/build-apk.yml ফাইলটিও অবশ্যই upload করতে হবে।
4. সব ফাইল main বা master branch-এ commit করুন।
5. Repository-তে Actions tab খুলুন। “Build Study Time APK” workflow বেছে Run workflow চাপুন (push করলে এটি নিজেও চালু হবে)।
6. Build শেষ হলে workflow run খুলে নিচের Artifacts অংশ থেকে StudyTime-debug-APK download করুন। ZIP extract করলে app-debug.apk পাবেন।
7. APK ফোনে খুলে Install করুন। প্রয়োজনে Settings থেকে ওই অ্যাপ/ব্রাউজারকে “Install unknown apps” অনুমতি দিন।

গুরুত্বপূর্ণ:
- এই ZIP-এ APK তৈরি করা নেই; এটি সোর্স কোড এবং cloud-build workflow।
- APK তৈরি হতে GitHub Actions-এ workflow সফলভাবে শেষ হতে হবে।
- Android-এর নোটিফিকেশন ও Exact Alarm অনুমতি চালু রাখুন। কিছু ফোনের battery optimization নোটিফিকেশন দেরি করাতে পারে।
- GitHub-এ ফাইল আপলোড করার সময় folder structure ঠিক রাখতে হবে, বিশেষ করে .github/workflows/build-apk.yml।
