package com.studytime.app;

import android.app.*;
import android.content.*;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import java.util.Calendar;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        MainActivity.createChannel(context);
        NotificationCompat.Builder b = new NotificationCompat.Builder(context, "study_reminder")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("📚 পড়তে বসার সময় হয়েছে!")
            .setContentText("মোবাইলটা একটু দূরে রাখো, বই-খাতা নিয়ে পড়তে বসো। তুমি পারবে! ❤️")
            .setStyle(new NotificationCompat.BigTextStyle().bigText("চলো, আর দেরি নয়—পড়তে বসো! আজকের ছোট্ট চেষ্টা তোমার স্বপ্নের পথে এগিয়ে দেবে। 💪"))
            .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true);
        NotificationManager nm = (NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(2001, b.build());
        int h = context.getSharedPreferences("MainActivity", Context.MODE_PRIVATE).getInt("hour", 20);
        int m = context.getSharedPreferences("MainActivity", Context.MODE_PRIVATE).getInt("minute", 0);
        MainActivity.scheduleReminder(context, h, m);
    }
}
