package com.studytime.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            android.content.SharedPreferences p = context.getSharedPreferences("MainActivity", Context.MODE_PRIVATE);
            if (p.getBoolean("enabled", false)) {
                MainActivity.scheduleReminder(context, p.getInt("hour", 20), p.getInt("minute", 0));
            }
        }
    }
}
