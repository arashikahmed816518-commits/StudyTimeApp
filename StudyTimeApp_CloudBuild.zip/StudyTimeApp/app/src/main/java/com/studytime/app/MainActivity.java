package com.studytime.app;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.Calendar;

public class MainActivity extends Activity {
    private TimePicker timePicker;
    private TextView status;
    private int hour = 20, minute = 0;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        createChannel();
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 12);
        }
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(28, 36, 28, 28);
        root.setBackgroundColor(0xFFF4F7FB);

        TextView icon = new TextView(this); icon.setText("📚"); icon.setTextSize(48); icon.setGravity(Gravity.CENTER);
        root.addView(icon, full(90));
        TextView title = new TextView(this); title.setText("Study Time"); title.setTextSize(30); title.setTextColor(0xFF17324D); title.setGravity(Gravity.CENTER); title.setTypeface(null, 1);
        root.addView(title, full(48));
        TextView sub = new TextView(this); sub.setText("প্রতিদিন একটু একটু করে স্বপ্নের পথে এগিয়ে যাও ❤️"); sub.setTextSize(16); sub.setTextColor(0xFF43566B); sub.setGravity(Gravity.CENTER);
        root.addView(sub, full(65));

        TextView label = new TextView(this); label.setText("রিমাইন্ডারের সময় বেছে নাও"); label.setTextSize(18); label.setTextColor(0xFF17324D); label.setGravity(Gravity.CENTER); label.setPadding(0, 18, 0, 8);
        root.addView(label, full(48));
        timePicker = new TimePicker(this); timePicker.setIs24HourView(false);
        Calendar now = Calendar.getInstance(); timePicker.setHour(20); timePicker.setMinute(0);
        root.addView(timePicker, full(180));

        Button save = new Button(this); save.setText("🔔 রিমাইন্ডার চালু করো");
        root.addView(save, full(60));
        status = new TextView(this); status.setText("প্রতিদিন রাত ৮টায় পড়তে বসার রিমাইন্ডার"); status.setTextSize(15); status.setTextColor(0xFF19734A); status.setGravity(Gravity.CENTER); status.setPadding(0, 18, 0, 12);
        root.addView(status, full(70));

        TextView encouragement = new TextView(this);
        encouragement.setText("✨ আজকের ছোট্ট চেষ্টা, আগামীকালের বড় সাফল্য।\nমোবাইলটা পাশে রেখে বই-খাতা নিয়ে বসো!");
        encouragement.setTextSize(17); encouragement.setTextColor(0xFF243B53); encouragement.setGravity(Gravity.CENTER);
        root.addView(encouragement, full(100));

        save.setOnClickListener(v -> {
            hour = timePicker.getHour(); minute = timePicker.getMinute();
            if (Build.VERSION.SDK_INT >= 31) {
                AlarmManager am = (AlarmManager)getSystemService(ALARM_SERVICE);
                if (!am.canScheduleExactAlarms()) {
                    try { startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        Uri.parse("package:" + getPackageName()))); }
                    catch (Exception ignored) {}
                    Toast.makeText(this, "অনুমতি চালু করে আবার রিমাইন্ডার সেট করুন", Toast.LENGTH_LONG).show();
                    return;
                }
            }
            scheduleReminder(this, hour, minute);
            getSharedPreferences("MainActivity", MODE_PRIVATE).edit().putInt("hour", hour).putInt("minute", minute).putBoolean("enabled", true).apply();
            status.setText(String.format("✅ প্রতিদিন %02d:%02d-এ রিমাইন্ডার সেট হয়েছে", hour, minute));
            Toast.makeText(this, "রিমাইন্ডার সেট করা হয়েছে!", Toast.LENGTH_SHORT).show();
        });

        setContentView(root);
        if (getSharedPreferences("MainActivity", MODE_PRIVATE).getBoolean("enabled", false)) {
            hour = getSharedPreferences("MainActivity", MODE_PRIVATE).getInt("hour", 20);
            minute = getSharedPreferences("MainActivity", MODE_PRIVATE).getInt("minute", 0);
            timePicker.setHour(hour); timePicker.setMinute(minute);
            status.setText(String.format("🔔 প্রতিদিন %02d:%02d-এ রিমাইন্ডার চালু আছে", hour, minute));
            scheduleReminder(this, hour, minute);
        }
    }

    private android.widget.LinearLayout.LayoutParams full(int h) {
        return new android.widget.LinearLayout.LayoutParams(-1, h);
    }

    static void createChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel("study_reminder", "Study reminders", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Daily reminders to sit down and study");
            ((NotificationManager)c.getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    static void scheduleReminder(Context c, int h, int m) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, h); cal.set(Calendar.MINUTE, m); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0);
        if (cal.getTimeInMillis() <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1);
        Intent i = new Intent(c, ReminderReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(c, 1001, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager)c.getSystemService(ALARM_SERVICE);
        if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
        else am.setExact(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
    }
}
